package tvs.lib;

public class Resources {
    public static void LoadTest() {
        Tvslib.LOGGER.info("Testing TVS-lib access");

    }


}
